# Contributing to NOVA OS

Thanks for helping improve this prototype.

- Describe the problem and exact steps to reproduce it.
- Include Android version, device model, and build-tool versions when relevant.
- Keep changes small and explain why they are needed.
- Do not commit passwords, access tokens, private files, or personal data.
- Verify the JavaScript syntax and test on a real device where possible.
- Respect the MIT license and the licenses of any added assets or dependencies.

NOVA OS is currently a WebView-based concept app, not an AOSP-based operating system image.
