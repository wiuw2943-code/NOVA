# Changelog

## 0.1.1-open-source-fix (2026-10-25)

- Improved external browser URL handling and URL validation.
- Added Android system document pickers for files, images, audio, and video.
- Added launchers for the system camera and clock.
- Made the Android back action close the active NOVA panel first.
- Added an online weather page entry point.
- Hardened calculator result handling.
- Added MIT license and contribution guidance.

Known limitations: no embedded browser engine UI, no full media player, no built-in weather API, no full camera preview, and no direct privileged Wi-Fi/brightness controls.

## 0.1.2 Feature Pack
- 新增任务清单（本地保存、完成标记、删除、清理已完成）。
- 新增秒表与倒计时工具。
- 日历增加本地日程添加和删除。
- 备忘录增加清空与文本导出。
- 主题选择保存到本地并在启动时恢复。
- 设置搜索可以筛选设置项；首页搜索入口改为应用搜索。
- 新增隐私中心、本地数据 JSON 备份与清除功能。
- 应用中心提供内置工具快捷入口。


## 0.1.3 — 2026-10-25
- 新增应用内通知中心和 Android 系统通知桥接。
- 音乐/视频面板增加 HTML5 播放控件，支持从系统文件选择器载入 URI。
- 新增会话级应用锁 UI 演示，并清楚标注非安全认证。
- 控制中心/连接状态面板显示 Android 网络与蓝牙有限状态；网页预览标注无法读取系统状态。
- 更新 Android 权限声明、版本号和中文功能边界文档。
- 未声称已完成实机编译或测试。
