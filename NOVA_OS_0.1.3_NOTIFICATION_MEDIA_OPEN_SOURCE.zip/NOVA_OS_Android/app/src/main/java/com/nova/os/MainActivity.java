package com.nova.os;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.bluetooth.BluetoothAdapter;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.provider.MediaStore;
import org.json.JSONObject;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQUEST_BLUETOOTH_ENABLE = 401;
    private static final int REQUEST_BLUETOOTH_PERMISSION = 402;
    private static final int REQUEST_FILE = 410;
    private static final int REQUEST_IMAGE = 411;
    private static final int REQUEST_AUDIO = 412;
    private static final int REQUEST_VIDEO = 413;
    private static final int REQUEST_CAMERA = 414;
    private static final int REQUEST_POST_NOTIFICATIONS = 415;
    private static final String NOTIFICATION_CHANNEL_ID = "nova_general";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme()) || "about".equals(uri.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this, "没有可打开此链接的应用", Toast.LENGTH_SHORT).show(); }
                return true;
            }
        });
        webView.addJavascriptInterface(new NovaBridge(), "NovaNative");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class NovaBridge {
        @JavascriptInterface public void openWifiSettings() { runOnUiThread(() -> launch(Settings.ACTION_WIFI_SETTINGS)); }
        @JavascriptInterface public void openSoundSettings() { runOnUiThread(() -> launch(Settings.ACTION_SOUND_SETTINGS)); }
        @JavascriptInterface public void openDisplaySettings() { runOnUiThread(() -> launch(Settings.ACTION_DISPLAY_SETTINGS)); }
        @JavascriptInterface public void openAppSettings() { runOnUiThread(() -> launch(Settings.ACTION_APPLICATION_SETTINGS)); }
        @JavascriptInterface public void openSystemSettings() { runOnUiThread(() -> launch(Settings.ACTION_SETTINGS)); }
        @JavascriptInterface public void requestBluetoothEnable() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_BLUETOOTH_PERMISSION);
                    return;
                }
                Intent enable = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                try { startActivityForResult(enable, REQUEST_BLUETOOTH_ENABLE); }
                catch (ActivityNotFoundException e) { launch(Settings.ACTION_BLUETOOTH_SETTINGS); }
            });
        }
        @JavascriptInterface public String getDeviceStatus() {
            JSONObject out = new JSONObject();
            boolean networkConnected = false, wifiConnected = false;
            String networkType = "未知";
            try {
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                Network active = cm == null ? null : cm.getActiveNetwork();
                NetworkCapabilities caps = (cm == null || active == null) ? null : cm.getNetworkCapabilities(active);
                if (caps != null) {
                    networkConnected = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
                    wifiConnected = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
                    if (wifiConnected) networkType = "Wi-Fi";
                    else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) networkType = "移动网络";
                    else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) networkType = "以太网";
                    else networkType = networkConnected ? "其他网络" : "无互联网能力";
                } else networkType = "未连接";
            } catch (Exception ignored) { networkType = "读取失败"; }
            String bt = "unknown", btDetail = "状态不可用";
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    bt = "permission"; btDetail = "需要用户授予附近设备/蓝牙权限";
                } else {
                    BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                    if (adapter == null) { bt = "unavailable"; btDetail = "设备不支持蓝牙"; }
                    else { bt = adapter.isEnabled() ? "on" : "off"; btDetail = "来自 Android 蓝牙适配器状态"; }
                }
            } catch (SecurityException e) { bt = "permission"; btDetail = "Android 拒绝读取蓝牙状态"; }
            try {
                out.put("networkConnected", networkConnected);
                out.put("wifiConnected", wifiConnected);
                out.put("networkType", networkType);
                out.put("bluetooth", bt);
                out.put("bluetoothDetail", btDetail);
                out.put("mode", "Android 原生状态读取；开关仍由系统设置/确认对话框控制");
            } catch (Exception ignored) { }
            return out.toString();
        }
        @JavascriptInterface public void showNotification(String title, String body) {
            runOnUiThread(() -> postSystemNotification(title, body));
        }
        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> {
                try {
                    Uri uri = Uri.parse(url);
                    String scheme = uri.getScheme();
                    if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) {
                        Toast.makeText(MainActivity.this, "只允许打开 HTTP/HTTPS 网页", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception e) { Toast.makeText(MainActivity.this, "无法打开网页，请检查浏览器是否可用", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void openFilePicker() { runOnUiThread(() -> pickDocument("*/*", REQUEST_FILE)); }
        @JavascriptInterface public void openImagePicker() { runOnUiThread(() -> pickDocument("image/*", REQUEST_IMAGE)); }
        @JavascriptInterface public void openAudioPicker() { runOnUiThread(() -> pickDocument("audio/*", REQUEST_AUDIO)); }
        @JavascriptInterface public void openVideoPicker() { runOnUiThread(() -> pickDocument("video/*", REQUEST_VIDEO)); }
        @JavascriptInterface public void openCamera() {
            runOnUiThread(() -> {
                try { startActivityForResult(new Intent(MediaStore.ACTION_IMAGE_CAPTURE), REQUEST_CAMERA); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "没有可用的相机应用", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void openClock() {
            runOnUiThread(() -> {
                try { startActivity(new Intent("android.intent.action.SHOW_ALARMS")); }
                catch (Exception e) {
                    try { startActivity(new Intent("android.intent.action.SHOW_TIMERS")); }
                    catch (Exception ignored) { Toast.makeText(MainActivity.this, "无法打开系统时钟", Toast.LENGTH_SHORT).show(); }
                }
            });
        }
    }

    private void pickDocument(String mimeType, int requestCode) {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mimeType);
            startActivityForResult(intent, requestCode);
        } catch (Exception e) {
            Toast.makeText(this, "系统文件选择器不可用", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            if (requestCode == REQUEST_CAMERA) Toast.makeText(this, "已取消拍摄", Toast.LENGTH_SHORT).show();
            return;
        }
        if (requestCode == REQUEST_CAMERA) {
            Toast.makeText(this, "相机已返回；部分相机不会自动保存照片到本应用", Toast.LENGTH_SHORT).show();
            return;
        }
        Uri uri = data == null ? null : data.getData();
        if (uri == null || webView == null) return;
        try { if (data != null && (data.getFlags() & Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) != 0) getContentResolver().takePersistableUriPermission(uri, data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION)); } catch (Exception ignored) { }
        String label;
        if (requestCode == REQUEST_IMAGE) label = "照片";
        else if (requestCode == REQUEST_AUDIO) label = "音频";
        else if (requestCode == REQUEST_VIDEO) label = "视频";
        else label = "文件";
        String js = "handleNativeSelection(" + JSONObject.quote(label) + "," + JSONObject.quote(uri.toString()) + ")";
        webView.evaluateJavascript(js, null);
        Toast.makeText(this, label + "已选择", Toast.LENGTH_SHORT).show();
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BLUETOOTH_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            try { startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_BLUETOOTH_ENABLE); }
            catch (ActivityNotFoundException e) { launch(Settings.ACTION_BLUETOOTH_SETTINGS); }
        } else if (requestCode == REQUEST_BLUETOOTH_PERMISSION) {
            Toast.makeText(this, "未授予蓝牙权限，可在系统设置中开启蓝牙", Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQUEST_POST_NOTIFICATIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "通知权限已允许，请再次点击发送系统通知", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "未授予通知权限，通知只会保存在 NOVA 应用内", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void postSystemNotification(String title, String body) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQUEST_POST_NOTIFICATIONS);
            Toast.makeText(this, "请在系统弹窗中允许通知后再次发送", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) { Toast.makeText(this, "系统通知服务不可用", Toast.LENGTH_SHORT).show(); return; }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "NOVA 通知", NotificationManager.IMPORTANCE_DEFAULT);
                channel.setDescription("NOVA OS 应用通知");
                manager.createNotificationChannel(channel);
            }
            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pending = PendingIntent.getActivity(this, 1, open, (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0) | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, NOTIFICATION_CHANNEL_ID) : new Notification.Builder(this);
            Notification notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title == null ? "NOVA OS" : title).setContentText(body == null ? "" : body).setAutoCancel(true).setContentIntent(pending).build();
            manager.notify((int)(System.currentTimeMillis() & 0x7fffffff), notification);
            Toast.makeText(this, "已发送 Android 系统通知", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "系统通知发送失败：" + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void launch(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { Toast.makeText(this, "此系统设置页面不可用", Toast.LENGTH_SHORT).show(); }
    }
    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("document.getElementById('panel') && document.getElementById('panel').classList.contains('open')", value -> {
            if ("true".equals(value)) {
                webView.evaluateJavascript("closePanel()", null);
            } else if (webView.canGoBack()) {
                webView.goBack();
            } else {
                MainActivity.super.onBackPressed();
            }
        });
    }
}
